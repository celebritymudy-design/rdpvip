# Five matching Windows GitHub Actions jobs

This is **software provisioning**, not full RDP cloning or a persistent RDP service.

## Start
1. Put `.github/workflows/five-windows.yml` and `scripts/install-software.ps1` in your GitHub repository, preserving folder paths.
2. Edit the `$packages` list in `scripts/install-software.ps1` to choose software.
3. Open GitHub repository -> Actions -> Five Windows - Same Software -> Run workflow.
4. Review five jobs, Windows 1 through Windows 5. Each job installs the same packages.
5. For remote access, integrate your own *authorized*, secure remote-access approach in the same job, subject to GitHub policies. This example deliberately does not expose RDP or configure insecure access.

## Important limitations
- GitHub-hosted runners are temporary: each job starts from a fresh image and loses changes after completion.
- A successful workflow does not mean five persistent RDP machines exist.
- GitHub-hosted jobs have execution and concurrency limits; check your account and GitHub documentation.
- Package installers can change; for reproducibility, pin specific versions where possible.
- Chocolatey is expected on the selected GitHub Windows image; availability is verified by the script, not guaranteed forever.
- If you require five always-on machines with identical software and user settings, use five persistent VMs from a generalized golden image or managed provisioning instead.

Official references:
- https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/run-job-variations
- https://docs.github.com/en/actions/reference/limits
- https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax
